﻿# DEC-014_FRONTEND_ZERO_LOGIC

Legacy DEC artifact.
