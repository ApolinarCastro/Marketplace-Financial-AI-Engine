---
tags:
  - architecture
  - governance
  - api
status: active
version: 1.0
---

# API Governance Layer

## Overview
All external APIs are governed by a strict mutability policy to protect the `Single Financial Truth` embedded within the core Ledgers and Engines.

## API Levels

- **Nivel A (Contextual)**: 
  - *Purpose*: Provide executive context (dashboards, metrics).
  - *Constraint*: Read-only. Must not touch `marketplace_ledger_v1`.

- **Nivel B (Enrichment)**:
  - *Purpose*: Enrich existing records (e.g. uploading a DTE).
  - *Constraint*: Must delegate logic to the core pipeline. (e.g. `/api/v4/upload/dte` forwards to `DTEIndexer`). Cannot modify financial math.

- **Nivel C (Experimental)**:
  - *Purpose*: New feature prototyping.
  - *Constraint*: Isolated from production data.

## Mutability Rule
`Toda API externa deberá cumplir: No modificar Ledger. No modificar ETL. No modificar MarketplaceAuditorEngine. No modificar cálculos.`
